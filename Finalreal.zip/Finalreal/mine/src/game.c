#include "game.h"

extern GameState game_state;
pthread_mutex_t mutex_game = PTHREAD_MUTEX_INITIALIZER;
extern pthread_mutex_t mutex_game_state;

const int shapes[SHAPES][ROTATIONS][4][4] = {
    // I
    {{{0, 0, 0, 0}, {1, 1, 1, 1}, {0, 0, 0, 0}, {0, 0, 0, 0}},

     {{0, 0, 1, 0}, {0, 0, 1, 0}, {0, 0, 1, 0}, {0, 0, 1, 0}},

     {{0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 1}, {0, 0, 0, 0}},

     {{0, 1, 0, 0}, {0, 1, 0, 0}, {0, 1, 0, 0}, {0, 1, 0, 0}}},
    // O
    {{{0, 0, 0, 0}, {0, 1, 1, 0}, {0, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 1, 0}, {0, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 1, 0}, {0, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 1, 0}, {0, 1, 1, 0}, {0, 0, 0, 0}}},
    // T
    {{{0, 0, 0, 0}, {0, 1, 0, 0}, {1, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 0, 0}, {0, 1, 1, 0}, {0, 1, 0, 0}},
     {{0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 0}, {0, 1, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 0, 0}, {1, 1, 0, 0}, {0, 1, 0, 0}}},
    // S
    {{{0, 0, 0, 0}, {0, 0, 1, 1}, {0, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 0, 0}, {0, 1, 1, 0}, {0, 0, 1, 0}},
     {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 1, 1, 0}, {1, 1, 0, 0}},
     {{0, 0, 0, 0}, {1, 0, 0, 0}, {1, 1, 0, 0}, {0, 1, 0, 0}}},
    // Z
    {{{0, 0, 0, 0}, {1, 1, 0, 0}, {0, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 0, 1, 0}, {0, 1, 1, 0}, {0, 1, 0, 0}},
     {{0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 0, 0}, {0, 1, 1, 0}},
     {{0, 0, 0, 0}, {0, 1, 0, 0}, {1, 1, 0, 0}, {1, 0, 0, 0}}},
    // J
    {{{0, 0, 0, 0}, {1, 0, 0, 0}, {1, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 1, 0}, {0, 1, 0, 0}, {0, 1, 0, 0}},
     {{0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 0}, {0, 0, 1, 0}},
     {{0, 0, 0, 0}, {0, 1, 0, 0}, {0, 1, 0, 0}, {1, 1, 0, 0}}},
    // L
    {{{0, 0, 0, 0}, {0, 0, 1, 0}, {1, 1, 1, 0}, {0, 0, 0, 0}},
     {{0, 0, 0, 0}, {0, 1, 0, 0}, {0, 1, 0, 0}, {0, 1, 1, 0}},
     {{0, 0, 0, 0}, {0, 0, 0, 0}, {1, 1, 1, 0}, {1, 0, 0, 0}},
     {{0, 0, 0, 0}, {1, 1, 0, 0}, {0, 1, 0, 0}, {0, 1, 0, 0}}}};


void game_init(void) {
    for (int i = 0; i < GRID_HEIGHT; i++) {
        for (int j = 0; j < GRID_WIDTH; j++) {
            game_state.grid[i][j] = 0;
        }
    }
}

static int check_collision(Player* player)
{
    if (!player) return 1;
    
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (shapes[player->figure.figure_type][player->figure.rotation][i][j])
            {
                int new_x = player->figure.x + j;
                int new_y = player->figure.y + i;
                
                // Проверяем только актуальные границы
                if (new_x < 0) return 1;
                if (new_x >= GRID_WIDTH) return 1;
                if (new_y >= GRID_HEIGHT) return 1;
                
                // Проверяем столкновение с блоками только внутри стакана
                if (new_y >= 0 && game_state.grid[new_y][new_x]) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

static void move_figure(Player* player, int dx, int dy)
{
    if (!player) return;
    
    // Сохраняем исходное положение
    int original_x = player->figure.x;
    int original_y = player->figure.y;
    
    // Пробуем переместить
    player->figure.x += dx;
    player->figure.y += dy;

    // Если коллизия - возвращаем на место
    if (check_collision(player))
    {
        player->figure.x = original_x;
        player->figure.y = original_y;
    }
}

static void rotate_figure(Player* player)
{
    if (!player) return;
    
    int old_rotation = player->figure.rotation;
    player->figure.rotation = (player->figure.rotation + 1) % ROTATIONS;

    if (check_collision(player))
    {
        int offsets[][2] = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
        for (int i = 0; i < 4; i++)
        {
            player->figure.x += offsets[i][0];
            player->figure.y += offsets[i][1];
            if (!check_collision(player)) {
                return;
            }
            player->figure.x -= offsets[i][0];
            player->figure.y -= offsets[i][1];
        }
        player->figure.rotation = old_rotation;
    }
}

static void merge_figure(Player* player)
{
    if (!player) return;
    
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (shapes[player->figure.figure_type][player->figure.rotation][i][j])
            {
                int y = player->figure.y + i;
                int x = player->figure.x + j;
                if (y >= 0)
                {
                    game_state.grid[y][x] = player->figure.color;
                }
            }
        }
    }
}

static int clear_lines()
{
    int lines_cleared = 0;
    for (int i = GRID_HEIGHT - 1; i >= 0; i--)
    {
        int full = 1;
        for (int j = 0; j < GRID_WIDTH; j++)
        {
            if (!game_state.grid[i][j])
            {
                full = 0;
                break;
            }
        }
        if (full)
        {
            lines_cleared++;
            for (int k = i; k > 0; k--)
            {
                for (int j = 0; j < GRID_WIDTH; j++)
                {
                    game_state.grid[k][j] = game_state.grid[k - 1][j];
                }
            }
            for (int j = 0; j < GRID_WIDTH; j++)
            {
                game_state.grid[0][j] = 0;
            }
            i++;
        }
    }

    return lines_cleared;
}

static void new_figure(Player* player)
{
    if (!player) return;
    
    player->figure.rotation = 0;
    player->figure.x = GRID_WIDTH / 2 - 2;  // Центрирование с учетом размера
    player->figure.y = 0;
}

void handle_player_action(ActionMessage* msg)
{
    pthread_mutex_lock(&mutex_game);
    
    Player* player = NULL;
    for (int i = 0; i < game_state.player_count; i++) {
        if (game_state.players[i].id == msg->player_id) {
            player = &game_state.players[i];
            break;
        }
    }
    
    if (!player) {
        pthread_mutex_unlock(&mutex_game);
        return;
    }

    switch (msg->action)
    {
    case 'p':
        game_state.is_paused = !game_state.is_paused;
        break;
    case 'l':
        move_figure(player, -1, 0);
        break;
    case 'r':
        move_figure(player, 1, 0);
        break;
    case 'd':
        move_figure(player, 0, 1);
        break;
    case 'u':
        rotate_figure(player);
        break;
    case 's':
        while (1)
        {
            int old_y = player->figure.y;
            player->figure.y++;
            if (check_collision(player))
            {
                player->figure.y = old_y;
                break;
            }
        }
        break;
    default:
        break;
    }
    
    pthread_mutex_unlock(&mutex_game);
}

int update_game(void) {
    pthread_mutex_lock(&mutex_game);

    if (game_state.player_count == 0 || game_state.game_over) {
        pthread_mutex_unlock(&mutex_game);
        return 0;
    }

    Player* active_player = NULL;
    for (int i = 0; i < game_state.player_count; i++) {
        if (game_state.players[i].id == game_state.active_player_id) {
            active_player = &game_state.players[i];
            break;
        }
    }
    
    if (!active_player) {
        // Если активный игрок не найден, выбираем первого
        if (game_state.player_count > 0) {
            game_state.active_player_id = game_state.players[0].id;
            active_player = &game_state.players[0];
        } else {
            pthread_mutex_unlock(&mutex_game);
            return 0;
        }
    }

    int old_y = active_player->figure.y;
    active_player->figure.y++;

    if (check_collision(active_player)) {   
        active_player->figure.y = old_y;
        merge_figure(active_player);
        
        int lines = clear_lines();
        
        if (lines > 0) {
            active_player->score += lines * 100;
            if (active_player->score >= 1000) {
                int speed_boost = (active_player->score / 1000) * 30;
                game_state.delay_time = MAX(50, 200 - speed_boost);
            }
        }
        
        // Смена активного игрока
        int next_index = -1;
        for (int i = 0; i < game_state.player_count; i++) {
            if (game_state.players[i].id == game_state.active_player_id) {
                next_index = (i + 1) % game_state.player_count;
                break;
            }
        }
        
        if (next_index >= 0) {
            game_state.active_player_id = game_state.players[next_index].id;
        } else if (game_state.player_count > 0) {
            game_state.active_player_id = game_state.players[0].id;
        }
        
        // Находим нового активного игрока
        active_player = NULL;
        for (int i = 0; i < game_state.player_count; i++) {
            if (game_state.players[i].id == game_state.active_player_id) {
                active_player = &game_state.players[i];
                break;
            }
        }
        
        if (!active_player) {
            pthread_mutex_unlock(&mutex_game);
            return 0;
        }
        
        // Генерируем новую фигуру для активного игрока
        new_figure(active_player);
        
        // Проверяем коллизию для новой фигуры
        if (check_collision(active_player))
        {
            game_state.game_over = true;
            pthread_mutex_unlock(&mutex_game);
            return 1;
        }
    }
    
    pthread_mutex_unlock(&mutex_game);
    return 0;
}