#include "player.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
Player init_player(int socket, const char* nickname)
{
    Player player;
    player.id = -1;
    player.score = 0;
    strcpy(player.nickname, nickname);
    player.socket = socket;
    player.server_sock = 0;
    
    player.figure.x = 0;
    player.figure.y = 0;

    // Временные значения
    player.figure.figure_type = rand() % FIGURE_COUNT;
    player.figure.color = COLOR_START + (rand() % COLOR_COUNT);
    player.figure.rotation = 0;

    return player;
}

void add_player_to_gamestate(Player* player)
{
    if (game_state.player_count >= MAX_CLIENTS)
        return;

    // Массив доступных цветов (10 цветов)
    bool available_colors[COLOR_COUNT];
    for (int c = 0; c < COLOR_COUNT; c++) {
        available_colors[c] = true;
    }

    // Помечаем занятые цвета
    for (int i = 0; i < game_state.player_count; i++) {
        int color_id = game_state.players[i].figure.color - COLOR_START;
        if (color_id >= 0 && color_id < COLOR_COUNT) {
            available_colors[color_id] = false;
        }
    }

    // Собираем доступные цвета
    int available_color_count = 0;
    int available_color_ids[COLOR_COUNT];
    for (int c = 0; c < COLOR_COUNT; c++) {
        if (available_colors[c]) {
            available_color_ids[available_color_count++] = c;
        }
    }

    // Выбираем случайный доступный цвет
    if (available_color_count > 0) {
        int index = rand() % available_color_count;
        player->figure.color = COLOR_START + available_color_ids[index];
    } else {
        // Если все цвета заняты (не должно быть, так как MAX_CLIENTS=10 и COLOR_COUNT=10)
        player->figure.color = COLOR_START + (rand() % COLOR_COUNT);
    }

    // Для фигур: если игроков меньше FIGURE_COUNT (7), выбираем уникальную фигуру
    if (game_state.player_count < FIGURE_COUNT) {
        // Массив доступных фигур
        bool available_figures[FIGURE_COUNT];
        for (int f = 0; f < FIGURE_COUNT; f++) {
            available_figures[f] = true;
        }
        
        // Помечаем занятые фигуры
        for (int i = 0; i < game_state.player_count; i++) {
            int figure_id = game_state.players[i].figure.figure_type;
            if (figure_id >= 0 && figure_id < FIGURE_COUNT) {
                available_figures[figure_id] = false;
            }
        }

        // Собираем доступные фигуры
        int available_figure_count = 0;
        int available_figure_ids[FIGURE_COUNT];
        for (int f = 0; f < FIGURE_COUNT; f++) {
            if (available_figures[f]) {
                available_figure_ids[available_figure_count++] = f;
            }
        }

        // Выбираем случайную доступную фигуру
        if (available_figure_count > 0) {
            int index = rand() % available_figure_count;
            player->figure.figure_type = available_figure_ids[index];
        } else {
            // Если почему-то все фигуры заняты (но игроков < 7, этого быть не должно)
            player->figure.figure_type = rand() % FIGURE_COUNT;
        }
    } else {
        // Если игроков 7 или больше - разрешаем повторение фигур
        player->figure.figure_type = rand() % FIGURE_COUNT;
    }

    // Назначаем уникальный ID
    player->id = game_state.next_player_id++;
    
    // Центрирование фигуры для игрока
    player->figure.x = GRID_WIDTH / 2 - 2;
    player->figure.y = 0;

    game_state.players[game_state.player_count] = *player;
    game_state.player_count++;
    
    if (game_state.player_count == 1) {
        game_state.active_player_id = player->id;
        game_state.is_paused = false;
    }
}

void remove_player_from_gamestate(short player_id)
{
    // Находим индекс игрока
    int index = -1;
    for (int i = 0; i < game_state.player_count; i++) {
        if (game_state.players[i].id == player_id) {
            index = i;
            break;
        }
    }
    
    if (index == -1) return;
    
    // Закрываем сокет игрока
    close(game_state.players[index].socket);
    
    // Удаляем игрока
    for (int i = index; i < game_state.player_count - 1; i++) {
        game_state.players[i] = game_state.players[i + 1];
    }
    
    game_state.player_count--;
    
    // Обновляем активного игрока если нужно
    if (game_state.active_player_id == player_id) {
        if (game_state.player_count > 0) {
            // Выбираем следующего игрока в списке
            int next_index = (index < game_state.player_count) ? index : 0;
            game_state.active_player_id = game_state.players[next_index].id;
        } else {
            game_state.active_player_id = -1;
            game_state.is_paused = true;
        }
    }
}