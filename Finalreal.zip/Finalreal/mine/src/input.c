#include "input.h"

static char key_to_action(int key)
{
    switch (key)
    {
    case KEY_UP:
        return 'u';
    case KEY_DOWN:
        return 'd';
    case KEY_RIGHT:
        return 'r';
    case KEY_LEFT:
        return 'l';
    case 'q':
    case 'Q':
        return 'q';
    case 'p':
    case 'P':
        return 'p';
    case ' ': // Пробел
        return 's';
    default:
        return 0;
    }
}

void* player_input_thread(void* arg)
{
    Player player = *(Player*)arg;
    nodelay(stdscr, TRUE);
    
    while (!client_shutdown)  // Проверяем глобальный флаг завершения
    {
        int key = getch();
        if (key != ERR)
        {
            char action = key_to_action(key);
            if (action)
            {
                ActionMessage action_message;
                action_message.player_id = player.id;
                action_message.action = action;
                send_player_action(player.server_sock, &action_message);
                
                // Выход при получении 'q'
                if (action == 'q') {
                    close(player.server_sock);
                    client_shutdown = 1;
                    pthread_exit(NULL);
                }
            }
        }
        usleep(5000);
    }
    return NULL;
}