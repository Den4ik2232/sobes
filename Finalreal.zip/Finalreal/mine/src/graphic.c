#include "graphic.h"

WINDOW* game_win = NULL;
WINDOW* management_win = NULL;
WINDOW* stats_win = NULL;

WINDOW* create_window(int start_y,
                      int start_x,
                      int height,
                      int width,
                      Color main_color,
                      Color background_color,
                      const char* header_1,
                      const char* header_2)
{
    WINDOW* win = newwin(height, width, start_y, start_x);
    if (win == NULL)
    {
        perror("Error creating window\n");
        return NULL;
    }

    wbkgd(win, COLOR_PAIR(main_color));

    WINDOW* frame = newwin(height + 2, width + 2, start_y - 1, start_x - 1);
    if (frame == NULL)
    {
        delwin(win);
        perror("Error creating frame\n");
        return NULL;
    }

    wbkgd(frame, COLOR_PAIR(background_color));

    if (header_1 && *header_1)
    {
        wattron(frame, A_BOLD);
        mvwprintw(frame, 0, 1, "%s", header_1);
        wattroff(frame, A_BOLD);
    }

    if (header_2 && *header_2)
    {
        int text_x = (width - strlen(header_2));
        wattron(frame, A_BOLD);
        mvwprintw(frame, 0, text_x, "%s", header_2);
        wattroff(frame, A_BOLD);
    }

    wrefresh(frame);
    wrefresh(win);

    delwin(frame);

    return win;
}

static void init_color_pairs(void)
{
    init_pair(BACKGROUND, RED_COLOR_CODE, BACKGROUND_COLOR_CODE);
    init_pair(FIELD, BLACK_COLOR_CODE, FIELD_COLOR_CODE);
    init_pair(FRAME, BLACK_COLOR_CODE, FRAME_COLOR_CODE);
    init_pair(BLUE, BLACK_COLOR_CODE, BLUE_COLOR_CODE);
    init_pair(YELLOW, BLACK_COLOR_CODE, YELLOW_COLOR_CODE);
    init_pair(PURPLE, BLACK_COLOR_CODE, PURPLE_COLOR_CODE);
    init_pair(GREEN, BLACK_COLOR_CODE, GREEN_COLOR_CODE);
    init_pair(RED, BLACK_COLOR_CODE, RED_COLOR_CODE);
    init_pair(LIGHT_BLUE, BLACK_COLOR_CODE, LIGHT_BLUE_COLOR_CODE);
    init_pair(ORANGE, BLACK_COLOR_CODE, ORANGE_COLOR_CODE);
}

void init_graphic()
{
    initscr();
    cbreak();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    start_color();
    // use_default_colors();
    init_color_pairs();
    set_escdelay(0);
}

MenuChoice start_menu()
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 10;
    int width = 30;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* menu_win =
        create_window(start_y, start_x, height, width, FIELD, FRAME, NULL, NULL);

    if (menu_win == NULL)
    {
        endwin();
        perror("Error when creating windows\n");
        return MENU_ERROR;
    }

    keypad(menu_win, true);

    char* choices[] = {"Server", "Client", "Exit"};

    int n_choices = sizeof(choices) / sizeof(char*);
    int highlight = 0;
    int should_exit = 0;

    while (!should_exit)
    {
        for (int i = 0; i < n_choices; i++)
        {
            if (i == highlight)
            {
                wattron(menu_win, A_REVERSE);
                wattron(menu_win, A_BOLD);
                mvwprintw(
                    menu_win, i + 3, (width - strlen(choices[i])) / 2, "%s", choices[i]);
                wattroff(menu_win, A_BOLD);
                wattroff(menu_win, A_REVERSE);
            }
            else
            {
                wattron(menu_win, A_BOLD);
                mvwprintw(
                    menu_win, i + 3, (width - strlen(choices[i])) / 2, "%s", choices[i]);
                wattroff(menu_win, A_BOLD);
            }
        }

        wrefresh(menu_win);

        int ch = wgetch(menu_win);

        switch (ch)
        {
        case KEY_UP:
            highlight--;
            if (highlight == -1)
            {
                highlight = n_choices - 1;
            }
            break;
        case KEY_DOWN:
            highlight++;
            if (highlight == n_choices)
            {
                highlight = 0;
            }
            break;
        case ENTER_KEY:
            should_exit = 1;
            break;
        case ESC_KEY:
            highlight = n_choices - 1;
            should_exit = 1;
            break;
        default:
            break;
        }
    }

    delwin(menu_win);
    clear();
    refresh();

    return highlight;
}

ConnectionParams start_connection_window()
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 8;
    int width = 40;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* input_win = create_window(
        start_y, start_x, height, width, FIELD, FRAME, "Client Connection", NULL);

    keypad(input_win, TRUE);
    echo();

    ConnectionParams connection_params = {0};

    wattron(input_win, A_BOLD);
    mvwprintw(input_win, 1, 2, "Nickname: ");
    wattroff(input_win, A_BOLD);

    wgetnstr(
        input_win, connection_params.nickname, sizeof(connection_params.nickname) - 1);

    wattron(input_win, A_BOLD);
    mvwprintw(input_win, 3, 2, "Server IP: ");
    wattroff(input_win, A_BOLD);

    wgetnstr(input_win, connection_params.ip, sizeof(connection_params.ip) - 1);

    wattron(input_win, A_BOLD);
    mvwprintw(input_win, 5, 2, "Port: ");
    wattroff(input_win, A_BOLD);

    wgetnstr(input_win, connection_params.port, sizeof(connection_params.port) - 1);

    noecho();
    delwin(input_win);
    clear();
    refresh();

    return connection_params;
}

void ask_nickname(char* nickname)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 8;
    int width = 40;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* input_win = create_window(
        start_y, start_x, height, width, FIELD, FRAME, "Client Connection", NULL);

    keypad(input_win, TRUE);
    echo();
    mvwprintw(input_win, 1, 2, "Enter your nickname: ");
    mvwgetnstr(input_win, 2, 2, nickname, MAX_NICKNAME_LENGTH - 1);
    noecho();
    delwin(input_win);
    clear();
    refresh();
}

void show_error_message(const char* msg)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 3;
    int width = strlen(msg) + 4;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* err_win =
        create_window(start_y, start_x, height, width, FIELD, FRAME, "Error!", NULL);

    mvwprintw(err_win, 1, 2, "%s", msg);
    wrefresh(err_win);
    napms(2000);
    delwin(err_win);
    clear();
    refresh();
}

int create_players_window(void)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);
    const int height = GRID_HEIGHT;
    const int width = GRID_WIDTH * 2;
    int start_x = (cols - width * 2) / 2;
    int start_y = (rows - height) / 2;

    // bkgd(COLOR_PAIR(RED_COLOR_CODE));
    // refresh();

    game_win =
        create_window(start_y, start_x, height, width, FIELD, FRAME, "Tetris", NULL);
    if (!game_win)
    {
        endwin();
        printf("Failed to create window: check terminal size\n");
        return 1;
    }

    stats_win = create_window(start_y,
                              start_x + width + 3,
                              height / 2 + 2,
                              width + 10,
                              FIELD,
                              FRAME,
                              "Player",
                              "Score");
    if (!stats_win)
    {
        endwin();
        printf("Failed to create window: check terminal size\n");
        return 1;
    }
    management_win = create_window(start_y + (height - (height / 3)),
                                   start_x + width + 3,
                                   height / 3,
                                   width + 10,
                                   FIELD,
                                   FRAME,
                                   "Game managment",
                                   NULL);

    if (!management_win)
    {
        endwin();
        printf("Failed to create window: check terminal size\n");
        return 1;
    }
    wrefresh(game_win);
    wrefresh(stats_win);
    wrefresh(management_win);
    return 0;
}

void show_players_n_stats(GameState new_state)
{
    if (!stats_win)
        return;
    werase(stats_win);
    for (int i = 0; i < new_state.player_count; i++)
    {
        wattron(stats_win, A_BOLD);
        if (new_state.players[i].id == new_state.active_player_id) {
            wattron(stats_win, A_REVERSE);
        }
        mvwprintw(stats_win, i+1, 1, "%s", new_state.players[i].nickname);
        int text_x = (GRID_WIDTH * 2 + 10) - 10; // Примерное выравнивание для счета
        mvwprintw(stats_win, i+1, text_x, "%d", new_state.players[i].score);

        if (new_state.players[i].id == new_state.active_player_id) {
            wattroff(stats_win, A_REVERSE);
        }
        wattroff(stats_win, A_BOLD);
    }
    wrefresh(stats_win);
}

void show_game_managment(void)
{
    char pause[] = "p/P - pause";
    const int width = GRID_WIDTH * 2;
    int text_x = (width + 10 - strlen(pause));
    wattron(management_win, A_BOLD);
    mvwprintw(management_win, 0, 2, "%s", pause);
    mvwprintw(management_win, 2, 2, "SPACE - boost");
    mvwprintw(management_win, 4, 2, "^ - rotation");
    mvwprintw(management_win, 6, 2, "<  > - movement");
    mvwprintw(management_win, 0, text_x, "q/Q - exit");
    wattroff(management_win, A_BOLD);

    wrefresh(management_win);
}

void show_game_field(GameState new_state)
{
    if (!game_win)
        return;
    werase(game_win);
    for (int i = 0; i < GRID_HEIGHT; i++)
    {
        for (int j = 0; j < GRID_WIDTH; j++)
        {
            if (new_state.grid[i][j])
            {
                wattron(game_win, COLOR_PAIR(new_state.grid[i][j]));
                mvwprintw(game_win, i, j * 2, "  ");
                wattroff(game_win, COLOR_PAIR(new_state.grid[i][j]));
            }
        }
    }

    // Находим активного игрока по id
    Player* active_player = NULL;
    for (int idx = 0; idx < new_state.player_count; idx++) {
        if (new_state.players[idx].id == new_state.active_player_id) {
            active_player = &new_state.players[idx];
            break;
        }
    }

    // Отрисовка текущей фигуры активного игрока, если он есть
    if (active_player) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (shapes[active_player->figure.figure_type][active_player->figure.rotation][i][j]) {
                    int y = active_player->figure.y + i;
                    int x = (active_player->figure.x + j) * 2;
                    if (y >= 0 && y < GRID_HEIGHT && x >= 0 && x < GRID_WIDTH * 2) {
                        wattron(game_win, COLOR_PAIR(active_player->figure.color));
                        mvwprintw(game_win, y, x, "  ");
                        wattroff(game_win, COLOR_PAIR(active_player->figure.color));
                    }
                }
            }
        }
    }

    wrefresh(game_win);
}

void cleanup_ncurses(void)
{
    delwin(game_win);
    delwin(stats_win);
    delwin(management_win);
    endwin();
    clear();
}

void show_game_over_screen(GameState state)
{
    // Сохраняем текущие размеры терминала
    int rows, cols;
    getmaxyx(stdscr, rows, cols);
    
    // Очищаем экран
    clear();
    refresh();
    
    int width = 40;
    int height = 10;
    int start_x = (cols - width) / 2;
    int start_y = (rows - height) / 2;
    
    WINDOW* result_win = create_window(start_y, start_x, height, width, 
                                      FIELD, FRAME, "Game Results", NULL);
    
    if (!result_win) return;
    
    // Находим лучший счет и общую сумму
    int best_score = 0;
    int total_score = 0;
    
    for (int i = 0; i < state.player_count; i++) {
        total_score += state.players[i].score;
        if (state.players[i].score > best_score) {
            best_score = state.players[i].score;
        }
    }
    
    // Выводим результаты
    wattron(result_win, A_BOLD);
    mvwprintw(result_win, 2, 2, "Best player score: %d", best_score);
    mvwprintw(result_win, 4, 2, "Total players score: %d", total_score);
    wattroff(result_win, A_BOLD);
    
    // Выводим инструкцию
    const char* msg = "Press 'Q' to exit";
    wattron(result_win, A_BOLD);
    mvwprintw(result_win, 6, (width - strlen(msg)) / 2, "%s", msg);
    wattroff(result_win, A_BOLD);
    
    wrefresh(result_win);
    
    // Сохраняем ссылку на окно результатов
    game_win = result_win;
}