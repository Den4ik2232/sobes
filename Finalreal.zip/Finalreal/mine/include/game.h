#ifndef GAME_H
#define GAME_H

#include "common.h"
#include <pthread.h>

void game_init(void);
void handle_player_action(ActionMessage* msg);
int update_game(void);

#endif
