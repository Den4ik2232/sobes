#ifndef INPUT_H
#define INPUT_H

#include "common.h"
#include "network.h"
#include <ncurses.h>

void* player_input_thread(void* arg);

#endif
