#ifndef GRAPHIC_H
#define GRAPHIC_H

#include "common.h"

#include <ncurses.h>
#include <string.h>

#define ENTER_KEY 10
#define ESC_KEY 27

#define BACKGROUND_COLOR_CODE 6
#define FIELD_COLOR_CODE 245
#define FRAME_COLOR_CODE 240
#define BLUE_COLOR_CODE 21
#define YELLOW_COLOR_CODE 226
#define PURPLE_COLOR_CODE 53
#define GREEN_COLOR_CODE 28
#define RED_COLOR_CODE 124
#define LIGHT_BLUE_COLOR_CODE 39
#define ORANGE_COLOR_CODE 9
#define BLACK_COLOR_CODE 16

#define MAX_NICKNAME_LENGTH 50

extern WINDOW* game_win;
extern WINDOW* management_win;
extern WINDOW* stats_win;

void init_graphic();
void show_error_message(const char* msg);
MenuChoice start_menu();
ConnectionParams start_connection_window();
WINDOW* create_window(int start_y,
                      int start_x,
                      int height,
                      int width,
                      Color main_color,
                      Color background_color,
                      const char* header_1,
                      const char* header_2);
int create_players_window(void);
void show_players_n_stats(GameState new_state);
void show_game_managment(void);
void show_game_field(GameState new_state);
void cleanup_ncurses(void);
void ask_nickname(char* nickname);
void show_game_over_screen(GameState state);

#endif
