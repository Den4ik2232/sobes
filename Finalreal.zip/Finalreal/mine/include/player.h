#ifndef PLAYER_H
#define PLAYER_H

#include "common.h"

Player init_player(int socket, const char* nickname);
void add_player_to_gamestate(Player* player);
void remove_player_from_gamestate(short player_id);

#endif