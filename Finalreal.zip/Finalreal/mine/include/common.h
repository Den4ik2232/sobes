#ifndef COMMON_H
#define COMMON_H

#include <signal.h>  // Добавляем для sig_atomic_t

#define MAX_CLIENTS 10
#define GRID_HEIGHT 20
#define GRID_WIDTH 10
#define SHAPES 7
#define ROTATIONS 4

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

// Объявляем глобальные флаги завершения
extern volatile sig_atomic_t server_shutdown;
extern volatile sig_atomic_t client_shutdown;

#include <ncurses.h>
#include <pthread.h>
#include <stdbool.h>
#include <time.h> // Добавлено для clock_gettime

extern const int shapes[SHAPES][ROTATIONS][4][4];

typedef enum
{
    MENU_SERVER = 0,
    MENU_CLIENT,
    MENU_EXIT,
    MENU_ERROR
} MenuChoice;

typedef enum
{
    BACKGROUND = 1,
    FIELD,
    FRAME,
    BLUE,
    YELLOW,
    PURPLE,
    GREEN,
    RED,
    LIGHT_BLUE,
    ORANGE
} Color;

#define COLOR_START BLUE
#define COLOR_END ORANGE
#define COLOR_COUNT (COLOR_END - COLOR_START + 1)

typedef struct
{
    char nickname[50];
    char ip[16];
    char port[6];
} ConnectionParams;

typedef enum
{
    FIGURE_I,
    FIGURE_O,
    FIGURE_T,
    FIGURE_S,
    FIGURE_Z,
    FIGURE_J,
    FIGURE_L
} FigureType;

#define FIGURE_COUNT 7

typedef struct Figure
{
    FigureType figure_type;
    int rotation;
    Color color;
    int x;
    int y;
} Figure;

typedef struct Player
{
    short id;
    int socket;
    int server_sock;
    char nickname[50];
    short score;
    Figure figure;
} Player;

typedef struct GameState
{
    Player players[MAX_CLIENTS];
    char grid[GRID_HEIGHT][GRID_WIDTH];
    short player_count;
    short active_player_id;
    short next_player_id; // Добавлено для генерации уникальных ID
    bool is_paused;
    short delay_time;
    bool game_over;
} GameState;

typedef struct ActionMessage
{
    short player_id;
    char action;
} ActionMessage;

typedef struct GameOverMessage {
    bool game_over;
    short player_id;
    int score;
} GameOverMessage;

extern GameState game_state;
extern pthread_mutex_t mutex_game_state;

#endif